﻿

Dr. Acquinetta T. Davis

AI Boot Camp

03/21/2024

**ENGINEERED ARTS**

[**https://www.engineeredarts.co.uk/**](https://www.engineeredarts.co.uk/)

**Overview and Origin**

“***Engineered Arts (EAs)*** is a British company, established in October 2004, that specializes in the engineering, design, and manufacturing of humanoid robots.” (Engineered Arts, 2024) [Their range of products includes humanoid robots equipped with artificial intelligence for entertainment, informational, educational, and research purposes, serving science centers, theme parks, and businesses](https://pitchbook.com/profiles/company/484681-24#overview). “Engineered Arts combines art and technology, has a mission to create innovative and interactive robotic systems**.** They aim to push the boundaries of what robots can do by designing lifelike and expressive humanoid robots that engage with people in various contexts. Their creations are not only functional but also artistic, blurring the lines between technology and art. Through their work, they strive to inspire curiosity, creativity, and wonder in both individuals and audiences.” 

**Founder, Board Members, and Incorporation**

Engineering Arts, a limited company, was founded in October 2004 by Will Jackson, who also plays a pivotal role at the company. The board of EA comprises three members: Will Jackson, who is the Founder, Chief Executive Officer, and Director; Gill Spencer, the Director of Finance and Administration; and Nicholas Demarais, who serves as the Chairperson.

**Headquarters** 

“*EA* is currently located at** E1-E3 Church View Business Park

Bickland Water Road, Falmouth Cornwall TR11 4FZ England, United Kingdom +44 01326 000000.” (*Engineered Arts Overview*, 2016)

**Company Funding**

Engineered Arts is home to over 40 employees. It is a privately held company, whose financing status is private debt financed. To date, “Engineered Arts has secured a total investment of $2.95M across two funding rounds. The company’s initial funding round occurred on November 2, 2016. Its most recent funding round was a Seed round on May 29, 2019, amounting to $2.95M.” (*Engineered Arts - Company Profile - Tracxn*, 2024)

**Investors in Engineered Arts**

- Engineered Arts has 1 institutional investor - [Lloyds Bank](https://tracxn.com/d/companies/lloyds-bank/__VgfBKfFCOETxvZ4cuea_GW_6QZoQADGnSlMR5NGnLXo).
- [Tracy Rasburn](https://tracxn.com/a/d/people/gPLpiJEmXshaT6SRDpqKg0fGtztqN0SyHCFOmEaelsA/tracyrasburn) is only Angel Investor in Engineered Arts.
##
## **Concept for Engineered Arts and Idea of the Humanoid Entertainment Robot**
<https://www.engineeredarts.co.uk/about-us/our-story/>
## “Engineered Arts began its life as our robots do, as an idea in the mind of our founder and director, Will Jackson.
With a vision of what might be possible, he started gathering a group of talented local artists and engineers to produce mixed media installations in U.K. science centres and museums. Soon their mechanical creations were commissioned for sites such as the Eden Project, Glasgow Science Centre, Royal Botanic Gardens Kew and Centrum Kopernik in Warsaw.

But we were just getting started. At first, we were working with simple mechanical figures and standard industrial controllers. But in our hearts, our desire was to make something truly mesmerizing.” *(Profile: Who Are Engineered Arts?*, 2021)

“The journey of creating and building humanoid entertainment robots began in 2005 when the company was assigned the task of creating mechanical actors for the Mechanical Theatre at the Eden Project. Rather than constructing a random collection of figures, Engineered Arts devised a programmable figure adaptable for various uses.

This initiative led to the birth of RoboThespian Mark 1. This robot possessed the extraordinary ability to adopt any personality, making it a magnet for crowds in any setting. From these modest beginnings, the company has refined their humanoid robot, enhancing its human-like movements and interactive capabilities, primarily for use in exhibitions or on show floors.” (*Profile: Who Are Engineered Arts?*, 2021)

***EAs*** primary industry is other hardware; they also specialize in other commercial services business, and productivity software.















**Business Activities**

[**https://www.engineeredarts.co.uk/gallery/**](https://www.engineeredarts.co.uk/gallery/)

![](Aspose.Words.2bffd5a4-3bb5-4423-9e8f-c3ce8ba188bc.001.png "‌Engineer Arts")

Ameca Robot – The Future Face of Robotics

# ![](Aspose.Words.2bffd5a4-3bb5-4423-9e8f-c3ce8ba188bc.002.jpeg "Engineered Arts image 1")
# Anticipated Humanoid Robots at SXSW 2021
[https://www.engineeredarts.co.uk/engineered-arts-fireside-chat-at-sxsw-2021-features-robotic-humanoid-cleo/]()

<https://www.bing.com/videos/riverview/relatedvideo?q=Anticipated+Humanoid+Robots+at+SXSW+2021&mid=DCD94958A3E14AD1A3B7DCD94958A3E14AD1A3B7&FORM=VIRE>


**Problem to Be Solved** 

Simon Osborn, Sr. Mechanical Design Engineer, Engineered Arts states. “The primary challenge *EAs* is trying to solve is volume. Before we can address anything else, we have to work out the confines of the problem. Typically, it is a human-sized form. And that means you can’t have a robot that is supposed to look like a person but has giant arms to fit enormous motors.” (*Ameca*, 2024)

**Intended Customer–Market Size**

“The data does not specify the market size for Engineered Arts’ target customers. However, it is crucial to understand the wider scope of the global humanoid robot market. A report has valued the global humanoid robot market at USD 1.11 billion in 2022, with an expected compound annual growth rate (CAGR) of 21.1% from 2023 to 2030. This expansion is attributed to the increasing deployment of humanoid robots in surveillance, security, and various other roles.

Engineered Arts is part of a vibrant and rapidly expanding market. “Their innovative humanoid robots are shaping this progressive field, serving a variety of industries and purposes.” (*Humanoid Robot Market Size, Share & Growth Report, 2030*, 2023)

**Competitive Unfair Advantage**

**“Engineering Arts** offers a unique blend of creativity and technical expertise that sets them apart from their competitors. Here are some aspects of their approach that give them an **unfair advantage**:

1. **Integration of Art and Engineering**: Unlike many other firms that treat art and engineering as separate disciplines, **Engineering Arts** seamlessly integrates both. They recognize that creativity and technical skills can go hand-in-hand, allowing them to approach problems from multiple angles.
1. **Holistic Problem-Solving**: Their team leverages artistic thinking to find innovative solutions. By combining aesthetics, functionality, and engineering principles, they create designs that are not only efficient but also visually appealing.
1. **Cross-Disciplinary Collaboration**: **Engineering Arts** fosters collaboration between engineers, artists, and designers. This interdisciplinary approach leads to fresh ideas and unconventional solutions that competitors may overlook.
1. **Emphasis on Sustainability**: They utilize techniques like **3D printing** to build lightweight homes from recycled plastics. This commitment to sustainable practices gives them an edge in an environmentally conscious market.
1. **Senior Thesis Project**: One of their engineers worked on a senior thesis project focused on creating lightweight homes using recycled plastics. [This project demonstrates their commitment to pushing boundaries and finding novel solutions1](https://news.mit.edu/2022/channeling-creativity-through-art-and-engineering-1128).

**Engineering Arts** combines creativity, technical expertise, and sustainability to offer solutions that stand out in engineering and design.” (<https://binged.it/3TGDC0O>, 2024)

**Technologies Currently Being Used–Implementation** 

“**Engineering Arts** employs a blend of science, technology, engineering, arts, and mathematics (STEAM) to create innovative solutions. Let’s explore some technologies they use and their implementation:

1. **3D Printing**: **Engineering Arts** leverages **3D printing** technology to fabricate intricate designs and prototypes. They can create custom components, architectural models, and even lightweight homes using recycled plastics. “[This approach allows for rapid iteration and cost-effective production1](https://www.tandfonline.com/doi/full/10.1080/0020739X.2021.1922943).” (Belbase et al., 2021)
1. **Integration of Art and Engineering**: Unlike traditional engineering firms, **Engineering Arts** seamlessly integrates artistic creativity with technical expertise. They recognize that aesthetics and functionality go hand-in-hand. By combining these disciplines, they produce designs that are both visually appealing and efficient.
1. **Interdisciplinary Collaboration**: Their team collaborates across disciplines, including engineers, artists, and designers. This cross-pollination of ideas leads to innovative solutions. [For example, an engineer at **Engineering Arts** worked on a senior thesis project focused on creating lightweight homes from recycled plastics1]( t ).
1. **Sustainable Practices**: **Engineering Arts** emphasizes sustainability. By using recycled materials and energy-efficient designs, they contribute to environmentally conscious solutions. Their commitment to sustainable practices sets them apart from competitors.
1. **Artistic Thinking in Problem-Solving**: They apply artistic thinking to engineering challenges. This creative approach allows them to find unconventional solutions. For instance, they might reimagine structural elements or incorporate artistic elements into functional designs.” (*Lobster Tales*, 2024)

**Field** 

Technology, and Science

**Major trends and innovations of technology, and science over the last 5 to 10 years**

1. **THE PAST: WORLD, MEET THE INTERNET** (Lamey, 2018) (A–D)

“Looking back to the 1990s, the Internet was a [new commodity]( o ) that gradually became accessible to households and businesses. For those living in that era, the nostalgic sound of the painfully slow dial-up signal connecting to the Internet remains a vivid memory.

As the Internet gained popularity, technology advanced, eliminating the need for phone lines and providing faster connections to the World Wide Web. This transformation allowed more people to experience the benefits of the Internet and enjoy seamless online experiences.


- **WEBSITES AND BLOGGING ARE BORN**

Websites grew right alongside the Internet. Everyone had a GeoCities or Tripod website dedicated to themselves. In their early stages, websites were simple in both function and design. This was also when the blogging craze began to gain popularity with introducing “[weblogs]( o )“ (later shortened to “blogs”). Remember Xanga? If only we had known then what we know now.

- **FLOPPY DISCS: THE REAL-LIFE SAVE ICON**

After a few years, sharing information became increasingly convenient. Instead of relying on floppy discs or CD-ROMs, people began exchanging documents through email or storing extensive files on USB sticks or flash drives. This shift made the transfer of data much more efficient and streamlined.

As new technologies emerged, they built upon one another, resulting in more advanced, efficient, and powerful innovations. This rapid development of the Internet has profoundly affected the way we live, work, and function in today’s world.

1. **THE PRESENT: SNAPS, CHATS, AND DOUBLE TAPS**

In just a decade’s time, access to the Internet has become almost universal, surpassing the days of dial-up. Nowadays, it is a rare occurrence to find a coffee shop, library, or any place of business without the convenience of Wi-Fi connectivity. Even if Wi-Fi is out of reach, most individuals effortlessly connect to the Internet using their smartphones and personal hotspots through cellular data connections.

Today, the Internet connects people and businesses all around the world. With a simple click, you can video call someone on the other side of the globe, order groceries to be delivered to your doorstep, or even attend classes from prestigious universities without leaving your home. The possibilities seem endless.

- **THERE’S AN APP FOR THAT**

With this anywhere/anytime access to the Internet, businesses have developed web applications to cater to the common needs of consumers. These applications can do everything from tracking food portions to sending massive amounts of information in a click of a button.  In a world that’s always on the go, these apps provide convenience and efficiency.

- **THE EVOLUTION AND REVOLUTION OF COMMUNICATION**

Communication has undergone a remarkable evolution. Remember the days of face-to-face conversations? Handwritten letters? Waiting by the phone—the kind with a cord? Technology continuously reshapes how we connect. Today, the most striking difference online is the ability to be personable in an impersonal environment. Constant connection is the name of the game. And with connection comes instant availability. Bluetooth connections, talk-to-text, messaging apps in every form. Whether you’re driving, in meetings, or at home, connections are everywhere.

1. **SOCIAL MEDIA: CONNECTING PEOPLE LIKE NEVER BEFORE** 

We’ve watched texting strengthen from the simple exchange of text-only messages to the emergence of visual elements, thanks to the widespread popularity of gifs, memes, emojis, and Bitmojis. In fact, with the rise of short-form video sharing, traditional text is becoming more concise (think Snapchat, Instagram Stories and Reels, Facebook Stories, etc.) and accompanied by shorthand abbreviations.

Social media platforms have taken over our lives. As of July 2023, 4.88 billion people, or 59.9% of the world’s population, use social media, according to a [Statista study](https://www.statista.com/statistics/617136/digital-population-worldwide/ "Look at the staggering statistics of people who use social media."). Facebook, X (formerly Twitter), Instagram, and TikTok are just a few examples of how people stay connected in today’s world. These platforms allow people to share their thoughts, pictures, and videos with friends and followers, making the world a smaller place. People can now connect with others who share similar interests, creating online communities and networks. Although superficial, this form of communication helps people stay closer to each other when they would have otherwise lost contact or never met.

- **FACE TO FACE (VIRTUALLY SPEAKING)**

Face-to-face conversations via technology are resurfacing, though, and even strengthening, thanks to higher-quality video and streaming capabilities (enter Skype, Microsoft Teams, Zoom, FaceTime, live streaming, etc.). With more people engaging in web/video conferencing online, geographic barriers that once hindered communication were torn down. Instead, companies can engage with consumers in a more human manner, people can talk to other people face-to-face with no costly travel, and reaching out to people all over the world is faster and easier.

The COVID-19 pandemic has reshaped the landscape of video-calling, making it a new norm both in the workplace and at home. As remote work and virtual meetings became necessary for safety, video-calling platforms became essential tools for collaboration and communication. From team meetings to virtual happy hours, video-calling provided a lifeline for maintaining connections in a time of physical distancing. Even with the pandemic in the rearview, the convenience and efficiency of video-calling remains a valuable way to stay connected in a fast-paced, globalized society.

- **CUTTING THE CORD: THE ERA OF VIDEO STREAMING**

Remember when Netflix was a primarily a DVD delivery company, sending your favorite movies through the mail? Back before binge-watching became our new normal.

Today, more and more people are [ditching traditional cable](https://www.ibc.org/trends/2020-in-review-did-otts-come-out-on-top/7127.article "Understand how streaming services are taking over the entertainment market."), opting for digital streaming and video services like Netflix, YouTube TV, and Hulu. Big brands are trying to keep up and compete, doing their best to one-up each other with original content, availability, and delivery channels (e.g., Apple TV+, Disney Plus, Prime Video, etc.). From our favorite TV shows to live sports events, streaming services have become the go-to for entertainment.

The rise of streaming has also changed the landscape for advertisers. With more people opting out of traditional cable and satellite television, businesses have shifted their focus towards digital advertising on streaming platforms. This allows them to reach a wider audience and target specific demographics with precision.

User-generated content is also a force to acknowledge. Thanks to streaming options like Facebook Live, Instagram Live, and TikTok Live, individuals and businesses can broadcast their own videos and content.  This has made it possible for anyone to create their own brand and have a platform to showcase their talents, ideas, and thoughts.

- **TODAY’S TECH FORECAST: ICLOUD DAYS AHEAD**

Cloud-based services have revolutionized the way people and companies operate. Instead of relying on a single device, more and more businesses are storing everything online. This shift is transforming traditional office environments and reshaping how people interact with companies. The days of flash drives are numbered, thanks to the prevalence of cloud storage options like iCloud, Google Drive, Dropbox, and FTP sites.

With an array of new technologies enabling seamless access to information and fostering connections, the future of technological developments looks incredibly promising.

1. **THE FUTURE: EMERGING TRENDS ON THE HORIZON**

As existing technologies continue to advance and integrate, both consumers and businesses can expect a wealth of opportunities with future technology. The pace of technological innovation will speed up, enabling greater efficiency and productivity in our work. While we can’t predict the future with certainty, we can speculate on the evolution of technology based on emerging media and current trends. Here are a few key trends to monitor in the years to come.

- **SMART IS THE NEW SEXY**

Smart technology has already seeped into our daily lives through the use of voice assistants, smart home devices, and wearable tech. With the continuous development of artificial intelligence (AI) and machine learning, we can expect to see smarter and more intuitive devices in our households. These advancements will not only provide convenience but also enhance safety and security.

- **AUGMENTED REALITY (AR) AND VIRTUAL REALITY (VR) TAKE CENTER STAGE**

Augmented reality (AR) and virtual reality (VR) have been slowly gaining traction in various industries, but their full potential is yet to be realized. From gaming and entertainment to education, training, and healthcare, [AR/VR technology](https://www.pcmag.com/news/augmented-reality-ar-vs-virtual-reality-vr-whats-the-difference "Learn the difference between AR and VR.") has the power to completely change the way we interact with our environment. As these technologies become more accessible and affordable, we can expect to see a surge in their use and application.

- **THE INTERNET OF THINGS (IOT)**

The [Internet of Things (IoT)](https://www.discovertec.com/iot "Read more about how IoT connects our devices.") is all about connecting everyday objects through the Internet. This tech has already made its mark in various gadgets, from smart appliances to cars and wearable fitness trackers. But that’s just the beginning. As IoT keeps evolving and merging with other tech, it’s poised to revolutionize our daily routines.

Imagine a world where your car alerts you to traffic jams, or your alarm clock tells you your coffee’s brewing. That’s the IoT magic, blurring the line between the physical and virtual realms. It’s like living in a sci-fi movie, with smart speakers, homes, and cars leading the charge.

Think of IoT as a massive network of devices—gadgets, vehicles, home appliances, you name it—all linked up and sharing data. The number of IoT-connected devices worldwide is forecast to [almost double]( o ) from 15.1 billion in 2020 to over 29 billion IoT devices in 2030. This isn’t some distant future; it’s happening now, or at least, it’s right around the corner.

In short, IoT isn’t just a buzzword; it’s a significant change that’s already transforming our lives and shaping the future.

- **WORKING REMOTELY: THE NEW NORM**

The COVID-19 pandemic triggered an [unprecedented transformation]( o ) in our workforce. Technology played a pivotal role in making remote work the new norm. Video conferencing platforms like Zoom, Microsoft Teams, and Google Meet bridged the physical gap, turning homes into virtual boardrooms and connecting teams across the globe. Collaborative tools, such as Slack and Trello ensured seamless coordination, even when separated by miles.

This shift has blurred the boundaries between home and office, with employees setting up home offices equipped with high-speed internet and ergonomic chairs. Remote work has not only freed us from the daily commute, but also provided flexible schedules and an improved work-life balance.

For businesses, remote work has presented cost-saving opportunities by reducing overhead costs associated with physical offices and granting access to a global talent pool. Remote work is poised to remain a permanent fixture in our work landscape, reshaping our understanding of the workplace and how we harmonize work and life. It serves as yet another testament to the profound impact of technology on our lives.

**ARTIFICIAL INTELLIGENCE**

[Artificial intelligence (AI)](https://www.discovertec.com/ai-solutions "Learn how AI is evolving the way we live and work.") may sound complex, but in simpler terms, it involves teaching computers to think and learn like humans. Over time, technological advancements have propelled AI forward, making it smarter and more capable. Think of AI as the brain behind tools like ChatGPT, which can chat with you like a human, or chatbots that assist with customer service inquiries. These AI-driven creations are just the beginning, showing how machines are learning to understand and interact with us.

The latest leap in AI innovation is generative AI, which uses an innovative model called [Stable Diffusion](innovative) to create photorealistic images, animations, and even videos from text and image prompts. For instance, [DALL-E 2](https://www.discovertec.com/blog/the-power-of-vector-based-ai "Learn how vector-based DALL-E 2 uses AI to generate images.") can create realistic images and artwork from natural language prompts, blurring the line between human and machine creativity. In the video domain, [Next Diffusion]( "Read how Next Diffusion is using generative AI in the video space.") stands out, enabling the manipulation of existing video footage to craft entirely new content. Whether it’s background in painting, face swapping, or the creation of hyper-realistic individuals, the possibilities in the realm of video editing are nothing short of remarkable.

AI’s influence echoes across industries, transforming how businesses operate. In customer service, AI-powered chatbots provide quick, personalized responses. Supply chain management relies on AI to predict trends and streamline logistics. In healthcare, AI analyzes complex medical data for disease predictions and treatments. Undoubtedly, AI is a fundamental change, refining how businesses function and interact with the world.

As we look to the future, AI’s trajectory is poised for astonishing heights, promising more personalized content and transformative breakthroughs in healthcare and scientific discovery. AI is our bridge to a future where technology becomes astoundingly human-like in its understanding and abilities.

- **WHY BOTHER KEEPING UP WITH TECHNOLOGY?**

It’s a valid question. Technology is in a constant state of flux, and it can sometimes feel overwhelming to keep up with an ever-moving target. But remember, staying abreast of technological advancements adds [value to your business](value).

Remaining up to date ensures that you don’t miss out on opportunities, become irrelevant, or fall behind your competitors. Remember Kodak? They taught us a valuable lesson: don’t fear embracing change.

Here are a few effective strategies to stay informed and keep pace:

- Follow industry blogs (including [ours](https://www.discovertec.com/blog "Check out DiscoverTec’s industry-leading blog.")!)
- Listen to industry thought leaders
- Engage with relevant topics on social media
- Join online and in-person groups
- Tune in to tech-focused podcasts
- Participate in tech forums
- Subscribe to pertinent e-Newsletters
- Utilize Google alerts

By implementing these approaches, you can navigate the ever-changing tech landscape with confidence and seize the advantages it presents.

1. **THE FINAL FRONTIER**

In a world where technology knows no bounds, space may not be the final frontier we once imagined. Instead, technology has become its own frontier, an ever-evolving force that reshapes our world daily. With every step we take into the realm of technology, we’re forging new habits and discovering novel ways of collaborating and thriving.

While the future remains uncertain, one thing is clear: we firmly believe in harnessing the incredible potential of technology to craft personalized solutions. The power of technology lies not just in its innovation, but in its ability to transform lives and businesses alike.”

**Other Major Companies in this Field**

[**https://www.youtube.com/watch?v=OQzeNqL-830**](https://www.youtube.com/watch?v=OQzeNqL-830)

(MacLeod, 2018)

**IRobot**–founded in 1990 by three MIT graduates, this company aims at building robots for space exploration and military defense along with consumer robots. It focuses on consumer robots for inside and outside chores in this day.

**DJI**-into flying camera stabilization systems that govern the camera placement and motion. The company’s headquarters are in China’s Silicon Valley, Shenzhen. They ensure high-end professional photography experience. Apart from this, it from this, it focuses on drones and unmanned aerial vehicle manufacturing.

**Alphabet Inc.**-Google painted the canvas of the robotics market when it launched its driverless cars project in 2009, under the name of Wayamo, whose parent company is Alphabet Inc. The first successful test drive was held in 2017. Google also put together its own custom driverless vehicle.

**Epson Robots**-It is the king of the industrial robotic market center with its leading factory automation products and solutions. Epson Robots boast of their SCARA robots that are second in the list of robots, judged based on performance.

**Rethink Robotics**-They brought a boom in the arena of collaborative robots called Baxter in 2012. The robots were handled by skilled technicians.  And now the company has refined the market and invested strategy in the field of robotics. 


**Business Impact**

[**https://www.engineeredarts.co.uk/about-us/our-story/**](https://www.engineeredarts.co.uk/about-us/our-story/)

- 100+ robots installed worldwide
- 15+ years of humanoid robot development
- [**Ameca**](https://www.engineeredarts.co.uk/robot/ameca/) displaying the forefront of human-robotics technology
- [**Mesmer**](https://www.engineeredarts.co.uk/robot/mesmer/) and [**RoboThespian**](https://www.engineeredarts.co.uk/robot/robothespian/) characters drawing more crowds than ever
- [**Quinn robots**]( t ) providing extraordinary customer service
- [**Custom robots** ](https://www.engineeredarts.co.uk/robot/custom-commissions/)designed and made for shows and exhibitions

**Core Metrics Used to Measure Success - Company Performance Based on Metrics**

[**https://fellow.app/blog/productivity/engineering-metrics-what-they-are-ways-to-measure-them/**](https://fellow.app/blog/productivity/engineering-metrics-what-they-are-ways-to-measure-them/)

Engineering Arts LTD, using their experience in 3D printing and the fusion of art with engineering, upholds high-performance standards based on a robust set of core metrics.

“1. **Lead Time**: The efficiency of Engineering Arts is clear in their ability to rapidly transform concepts into final products, with shorter lead times indicating greater efficiency.

2\. **Number of Story Points**: These metric gauges the complexity and volume of work required to complete tasks. Maintaining a consistent number of story points shows predictability in their workflow.

3\. **Meantime to Restore**: This key indicator measures the speed at which Engineering Arts can bounce back from disruptions or downtimes. A brief meantime to restore signifies formidable resilience.

4\. **Days Worked**: The total number of days worked reflects Engineering Arts’ productivity and how effectively they use resources.

5\. **Context Switching**: Engineering Arts strives to minimize context switching to enhance task completion efficiency, as excessive switching can impede effectiveness.

6\. Deployment Frequency: The regularity of deploying new features or updates is a testament to their agility and adaptability to change.

7\. **Change Failure Rate**: A critical metric that quantifies the frequency of unsuccessful changes. A low failure rate underscores their robust change implementation processes.

8\. **Rework Ratio**: This ratio measures the necessity for additional work on completed tasks. A reduced rework ratio indicates initial work of higher quality.

9\. **Work in Progress Balance**: Engineering Arts ensures a balanced workload to maintain a fluid workflow and avoid bottlenecks.

By integrating these core metrics with their strengths in interdisciplinary collaboration, sustainable practices, and artistic problem-solving, Engineering Arts LTD is well-positioned to thrive in their domain, blending technical acumen with creative innovation.”

**Performing Relative to Competitors (3)**

[**https://tracxn.com/d/companies/engineered-arts/__Z0qUE9_MlM1QumRm_Dn8KVX6P1WfAWhOKtIEuWNW8DY/competitors**](https://tracxn.com/d/companies/engineered-arts/__Z0qUE9_MlM1QumRm_Dn8KVX6P1WfAWhOKtIEuWNW8DY/competitors)

![Logo of Invento Robotics](Aspose.Words.2bffd5a4-3bb5-4423-9e8f-c3ce8ba188bc.003.png "Logo of Invento Robotics")[](https://tracxn.com/d/companies/invento-robotics/__DuWbb5bDp8FlR-O_FM_1GNW2e1WFe2_3D10puqScPhU)<a name="_hlt161841039"></a><a name="_hlt161841040"></a> [**Invento Robotics](https://tracxn.com/d/companies/invento-robotics/__DuWbb5bDp8FlR-O_FM_1GNW2e1WFe2_3D10puqScPhU)**:** Provider of an AI-based humanoid robot for enterprise

`                       `Applications

`                       `<https://binged.it/3Vm2XhL>

` `**Invento Robotics Key Metrics**

Page 1 | 1

- **Founded**

  2016

- **Funding**

$485K

- **Location**

  Bengaluru ([India](https://tracxn.com/d/geographies/india/__ujYf3QI9FSnpS3x-zJCSwnay2nENQhm1kAN-U8-6Kfg))

- **Investors**

[RISE](https://tracxn.com/d/venture-capital/rise/__9wOc_FLQxZu1-yIqNDOYltgEY5_C7vQaJsCvhSmWvIc), [Lumis Partners](https://tracxn.com/d/private-equity/lumis-partners/__8Sv2k0Gtrw7YTmm5TqDu1DmXzV8vMfzGARiK0QWczps) and[ 12 Others](https://tracxn.com/d/companies/invento-robotics/__DuWbb5bDp8FlR-O_FM_1GNW2e1WFe2_3D10puqScPhU)

- **Stage**

  Seed

- **Tracxn Score** 39/100
- **Latest Funding Round**

  Undisclosed, Seed, Aug 01, 2020


- **Employee Count**

  5 as on Mar 31, 2022

- **Annual Revenue**

  $136K as on Mar 31, 2022

- **Competitor Rank**

  1st out of 22 competitors with a Tracxn Score of 39/100 

- **Acquisitions**

  Invento Robotics has not made any acquisitions yet

- **Investments**

  Invento Robotics has not made any investments yet

**What does Invento Robotics do?**

Invento Robotics provides an artificial intelligence-based humanoid robot for enterprise applications. Known as Mitra, it has the capability to recognize guests with face recognition technology and engage them in conversations while alerting the hosts of guest arrival. Features speech recognition, interactive gestures, natural conversation, autonomous navigation, and face recognition solutions. Has a use case in banks, retail, healthcare, and hospitality sectors.

Clientele includes HDFC Bank, PVR Cinemas, Canara Bank, Genpact, and Indian School of Desing and Innovation.

![Logo of Hatapro Robotics](Aspose.Words.2bffd5a4-3bb5-4423-9e8f-c3ce8ba188bc.004.png "Logo of Hatapro Robotics") [**Hatapro Robotics**](https://tracxn.com/d/companies/hatapro-robotics/__2a2hG8hVj3Ecd4-3GSMDPfvIr1gHxc6QzHR0-dWbJ-M): Provider of palm-sized robot for customer engagement

`                         `<https://bit.ly/3IHX5b8>

` `**Hatapro Robotics Key Metrics**

- **Founded Year**

`            `2017

- **Location**

  Chiyoda City, [Japan](https://tracxn.com/d/geographies/japan/__hz_aW4kKQWJ9rbPLD4BlDqj695doLuzwM5DttdUEHR0)

- **Company Stage**

  Funding Raised** 

- **Competitor Rank**

  56th out of 461 competitors with a Tracxn Score of 22/100 


- **Acquisitions**

  Hatapro Robotics has made no acquisitions yet

- **Investments**

  Hatapro Robotics has made no investments yet

**What does Hatapro Robotics do?**

Hatapro Robotics is a Japanese technology company that has developed Zukku, which is a palm-sized robot for marketing purposes. It can be used as an interactive signage system that the company claims analyze customer characteristics in real time and proposes appropriate products. The company also offers OEM services to enterprises. 

![Logo of PNT Robotics](Aspose.Words.2bffd5a4-3bb5-4423-9e8f-c3ce8ba188bc.005.png "Logo of PNT Robotics")[**PNT Robotics**](): Platform offering robot-based advertising solutions.

`                 `<https://bit.ly/3INnSme>



**PNT Robotics Key Metrics**

- **Founded Year**

  2021

- **Location**

  Dombivli, [India](https://tracxn.com/d/geographies/india/__ujYf3QI9FSnpS3x-zJCSwnay2nENQhm1kAN-U8-6Kfg)

- **Company Stage**

  Seed

- **Total Funding**

  $33.6K

- **Latest Funding Round**


$33.6K, Conventional Debt, Jan 08, 2022

- **Competitor Rank**

  8th out of 24 competitors with a Tracxn Score of 12/100 [What is this?](https://help.tracxn.com/articles/6655284-what-is-tracxn-score)

- **Acquisitions**

  PNT Robotics has made no acquisitions yet


**What does PNT Robotics do?**

PNT is a platform offering robot-based advertising solutions. It leverages AI that allows users to create and analyze the performance of the ads. It also offers robotic solutions for multiple functions in the manufacturing and hospitality sectors.

Engineer Arts competes effectively with its counterparts by offering versatile, technologically advanced robotics solutions tailored to meet the diverse needs of enterprise clients across various sectors. Through continuous innovation and adaptation to market demands, Engineer Arts remains a formidable player in the competitive landscape of robotics and AI technologies.

**Recommendations**

Based on my reach, I would advise Engineered Arts to continue to step beyond all boundaries and create robots that can provide care and assistance to people with disabilities and who are moving into their senior years. Based on my research, I would recommend that Engineered Arts persist in pushing the limits and develop robots designed to offer care and assistance to individuals with disabilities and those transitioning into their senior years.

**Benefits of Assistive Care Robots**

[**https://bit.ly/49WBs2G]()**; <https://nyti.ms/3IHPSb7>; <https://bit.ly/3VsGAqW>** 

** The creation and provision of humanoid robots to assist individuals with disabilities and those entering their senior years can greatly benefit society and Engineered Arts in various ways:

**Enhanced Quality of Life**: Humanoid robots can offer significant assistance to individuals with disabilities and seniors, enabling them to carry out daily tasks more independently. This can greatly improve their quality of life by fostering autonomy and reducing dependence on caregivers.

**Increased Accessibility**: Engineered Arts can contribute substantially by providing humanoid robots tailored for individuals with disabilities and seniors, making assistive technology more accessible to a broader audience. This can bridge the gaps in healthcare services and support systems, especially in areas with scarce resources.

**Personalized Support**: Humanoid robots can be programmed and tailored to the specific needs and preferences of users, offering personalized aid and support. Whether it’s aiding with mobility, reminding about medications, performing household chores, or providing companionship, these robots can adjust to the unique needs of individuals, increasing their effectiveness and usefulness.

**Relief for Caregivers**: Humanoid robots can ease the load on caregivers by taking over routine tasks and offering consistent support to individuals with disabilities and older adults. This can lessen caregiver stress and prevent burnout, allowing them to concentrate on other caregiving aspects and enhancing their overall well-being.

**Promotion of Independence**: Engineered Arts can foster independence and confidence by enabling individuals with disabilities and older adults to perform tasks on their own with the help of humanoid robots. This can lead to more social activity participation, heightened community engagement, and a stronger sense of empowerment among users.

**Market Expansion**: By addressing the increasing demand for assistive technology, Engineered Arts can expand its market reach and tap into a growing sector, potentially leading to greater innovation and development in the field of humanoid robotics.

**Additional Products or Service Utilization**

Advances in technology over the years have led to a wide range of innovations for people with disabilities. These include quality of life inventions for people with mobility issues and speech impairments and even common color blindness.



- **Bionic limbs:** Long a staple of science fiction, bionic limbs have become a reality. Modern bionic prosthetics are capable of advanced and precise movement, allowing amputees to perform many day-to-day tasks that previously weren’t possible with artificial limbs. Scientists have developed [the world’s first truly bionic leg]( t ) and dozens of [bionic arms and hands](https://disabilityhorizons.com/2021/01/bionic-technology-amputees-disabilities/) capable of complex ranges of motion.
- **Virtual Reality (VR):** Some people have disabilities that limit their opportunities to go outside or travel. With the development of virtual reality, these people can see more of the world than ever before. This technology is becoming more and more accessible; all most users need to get into it is their smartphone and one of many affordable headsets. While more expensive options are available for immersive video game experiences, VR viewers can easily be found for under $10, and hundreds of free apps are available online.
- **Text-to-speech:** Communication is becoming easier for people who live with speech impairments, thanks to improvements in text-to-speech technology. Now easily accessible from everyday smartphones and laptops, text-to-speech allows people with a limited speaking ability to type out what they want to say and have it spoken aloud by advanced text analysis software. This technology has expanded to include realistic computerized voices, as well.
- **Color-blindness glasses:** Color blindness is one of the most common disabilities, affecting [1 in 12 men and 1 in 200 women](https://www.nhs.uk/conditions/colour-vision-deficiency/#:~:text=It's%20a%20common%20problem%20that,to%20someone%20with%20normal%20vision), according to statistics from the U.K. National Health Service. Special lenses for everyday glasses have been developed that counteract the effects of certain forms of color blindness. This allows colorblind people to see colors as they really are.

**Technologies Appropriate for Your Solution**

[**https://rb.gy/exefhg**]()

The reason the technologies for these solutions are appropriate is because these advanced technologies in AI enable people with disabilities to step into a world where their difficulties are understood and taken into consideration.

**Addendum**

*\* What solution does Engineering Arts offer that their competitors do not or cannot offer? (What is the unfair advantage they utilize?)*. (2024). Bing. <https://binged.it/3TGDC0O>

*Ameca*. (2024). Engineered Arts. <https://bit.ly/4cpi3sG>

Banks, M. (2021, January 11). *Innovations in Assistive Robotics Show Promise for People With Disabilities | RoboticsTomorrow*. Roboticstomorrow.com; Robotics Tomorrow. <https://www.roboticstomorrow.com/story/2021/10/innovations-in-assistive-robotics-show-promise-for-people-with-disabilities/17584/>

Belbase, S., Mainali, B. R., Kasemsukpipat, W., Tairab, H., Gochoo, M., & Jarrah, A. (2021). At the dawn of science, technology, engineering, arts, and mathematics (STEAM) education: prospects, priorities, processes, and problems. *International Journal of Mathematical Education in Science and Technology*, *53*(11), 1–37. <https://doi.org/10.1080/0020739x.2021.1922943>

Calvello, M. (2022, August 10). *Engineering Metrics: 10 Ways to Measure Them*. Fellow.app. <https://fellow.app/blog/productivity/engineering-metrics-what-they-are-ways-to-measure-them/>

*Engineered Arts*. (2023, September 14). Autode.sk. <https://autode.sk/3ILZuBq>

*Engineered Arts - Company Profile - Tracxn*. (2024). <https://bit.ly/3x1VF8H>

*Engineered Arts is a British company that specializes in the engineering, design, and manufacturing of humanoid robots. Established in October 2004 by Will Jackson, the company is headquartered in Cornwall, England*. (n.d.). Bing. Retrieved March 19, 2024, from <https://binged.it/499JSmk>

*Engineered Arts Overview*. (2016, November 8). Https://Pitchbook.com/Profiles/Company/484681-24#Overview; Pitchbook. <https://pitchbook.com/profiles/company/484681-24>Engineered Arts is a privately held company founded in 2004. With a team of 40 employees, they specialize in designing and manufacturing interactive humanoid robots. Their products are used for entertainment, information, education, and research, incorporating artificial intelligence. Engineered Arts’ humanoid robots find applications in science centers, theme parks, and businesses. The company is based in Cornwall, United Kingdom, and can be reached via their website at engineeredarts.co.uk.

*Engineered Arts talks hotly-anticipated humanoid robots at SXSW 2021 - Experience UK is the trade body for Great British companies that design, create and deliver world class visitor destinations, from museums to theme parks and everything in between. Members News By Engineered Arts*. (2024). Www.experienceuk.org. <https://www.experienceuk.org/members-news/engineered-arts-talks-hotly-anticipated-humanoid-robots-at-sxsw-2021>

*Hatapro Robotics - Company Profile - Tracxn*. (2024, March 9). Tracxn.com. <https://tracxn.com/d/companies/hatapro-robotics/__2a2hG8hVj3Ecd4-3GSMDPfvIr1gHxc6QzHR0-dWbJ-M>

Hersh, M. (2015). Overcoming Barriers and Increasing Independence – Service Robots for Elderly and Disabled People. *International Journal of Advanced Robotic Systems*, *12*(8), 114. <https://doi.org/10.5772/59230>

*Humanoid Robot Market Size, Share & Growth Report, 2030*. (2023). Www.grandviewresearch.com. [https://www.grandviewresearch.com/industry-analysis/humanoid-robot-market-report]()

*invento robotics*. (2024, March 24). Bing. <https://www.bing.com/search?pglt=171&q=invento+robotics&cvid=638ccf8f91604413ac89349f7adfa24f&gs_lcrp=EgZjaHJvbWUqBggBEAAYQDIGCAAQRRg5MgYIARAAGEAyBggCEAAYQDIGCAMQABhAMgYIBBAAGEAyBggFEAAYQDIGCAYQABhAMgYIBxAAGEAyBggIEEUYQTIHCAkQRRj8VdIBCDc0NTlqMGoxqAIAsAIA&FORM=ANNAB1&PC=HCTS>

Krishnaswamy, K. (2023). *Assistive Robotics for Activities of Daily Living | DO-IT*. Www.washington.edu. <https://www.washington.edu/doit/programs/accessengineering/adept/adept-accessibility-briefs/assistive-robotics-activities-daily>

Lamey, D. (2018, January 5). *THE EVOLUTION OF TECHNOLOGY: PAST, PRESENT AND FUTURE*. Discovertec.com; DiscoverTec. <https://www.discovertec.com/blog/evolution-of-technology>

*Lobster tales*. (2024). Bing. <https://www.bing.com/search?q=>

Łukasik, S., Tobis, S., Kropińska, S., & Suwalska, A. (2020). Role of Assistive Robots in the Care of Older People: Survey Study Among Medical and Nursing Students. *Journal of Medical Internet Research*, *22*(8), e18003. [https://doi.org/10.2196/18003]()

MacLeod, K. (2018, May 24). *Top 5 Robotics Companies in the World*. Www.youtube.com. <https://www.youtube.com/watch?v=OQzeNqL-830>

Martinez, C. (2021, March 5). *Artificial Intelligence Enhances Accessibility for People with Disabilities*. Inclusive City Maker. <https://www.inclusivecitymaker.com/artificial-intelligence-accessibility-examples-technology-serves-people-disabilities/>

*Photo Gallery*. (n.d.). Engineered Arts. Retrieved March 19, 2024, from <https://www.engineeredarts.co.uk/gallery/>

*PNT Robotics - Company Profile - Tracxn*. (2024, February 29). Tracxn.com. <https://tracxn.com/d/companies/pnt-robotics/__W-SS3f3rPu9fVsqiPW-6pdUTnCqW-TM8xS4UfxMIXVM>

*Profile: Who are Engineered Arts?* (2021, December 9). Technologymagazine.com. <https://technologymagazine.com/ai-and-machine-learning/profile-who-are-engineered-arts>

Tugend, A. (2022, March 29). How Robots Can Assist Students With Disabilities. *The New York Times*. <https://www.nytimes.com/2022/03/29/technology/ai-robots-students-disabilities.html>

*what does LTD stand for incorporation*. (2024). Bing. <https://www.bing.com/search?pglt=171&q=what+does+LTD+stand+for+incoporation&cvid=eeeec599347c4f56a874ada20f4cfe9d&gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIGCAEQABhAMgYIAhAAGEAyBggDEAAYQDIGCAQQABhAMgYIBRAAGEAyBggGEAAYQDIGCAcQABhAMgYICBAAGEAyBwgJEEUY_FXSAQkyMjU2OWowajGoAgCwAgA&FORM=ANNAB1&PC=HCTS>

